<?php
    session_start();
    if (!isset($_SESSION['rol'])) {
        header('Location: inicioses.php');
        exit();
    }
    if ($_SESSION['rol'] != 1) {
        header('Location: inicioses.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/file.ico">
</head>
<body background="images/sesion.jpg">   
<div class="menu container">
            <a href="#" class="logo">Registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="Menú">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <li><a href="admineventos.php">Registro de Eventos</a></li>
                        <li><a href="administradorregistra.php">Registros</a></li>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </nav>
        </div> 
    <section class="bonus">
        <?php
        // Conexión a la base de datos usando PDO
        include_once 'conexionpdoregistra.php';
        $db = new Database();
        $pdo = $db->conectar();

        // Inserción de datos
        if (isset($_POST['insertar'])) {
            $nomusuario = $_POST['nomusuario'];
            $clave = $_POST['clave'];
            $idrol = 2;
            $email = $_POST['email'];
            $telefono = $_POST['telefono'];
            $documento = $_POST['documento'];
            $foto = 'default-profile.jpg'; // Imagen por defecto

            // Manejo de la foto
            if (!empty($_FILES['foto']['name'])) {
                $target_dir = "images/";
                $target_file = $target_dir . basename($_FILES["foto"]["name"]);
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    $foto = basename($_FILES["foto"]["name"]);
                } else {
                    echo "Error al subir la foto.";
                }
            }

            $sql = "INSERT INTO usuarios (nomusuario, email, clave, telefono, documento, idrol, foto) VALUES (:nomusuario, :email, :clave, :telefono, :documento, :idrol, :foto)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'nomusuario' => $nomusuario,
                'email' => $email,
                'clave' => $clave,
                'telefono' => $telefono,
                'documento' => $documento,
                'idrol' => $idrol,
                'foto' => $foto
            ]);

            header("Location: administradorregistra.php");
            exit();
        }

        // Actualización de datos
        if (isset($_POST['actualizar'])) {
            $editar_id = $_GET['editar'];
            $actualiza_nomusuario = $_POST['nomusuario'];
            $actualiza_clave = $_POST['clave'];
            $actualiza_idrol = $_POST['idrol'];
            $actualiza_email = $_POST['email'];
            $actualiza_telefono = $_POST['telefono'];
            $actualiza_documento = $_POST['documento'];
            $actualiza_foto = $_POST['foto_actual'];

            // Manejo de la foto
            if (!empty($_FILES['foto']['name'])) {
                $target_dir = "images/";
                $target_file = $target_dir . basename($_FILES["foto"]["name"]);
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    $actualiza_foto = basename($_FILES["foto"]["name"]);
                } else {
                    echo "Error al subir la foto.";
                }
            }

            $update = "UPDATE usuarios SET nomusuario = :nomusuario,
                                           clave = :clave,
                                           idrol = :idrol,
                                           email = :email,
                                           telefono = :telefono,
                                           documento = :documento,
                                           foto = :foto
                      WHERE id = :id";
            $stmt = $pdo->prepare($update);
            $stmt->execute([
                'nomusuario' => $actualiza_nomusuario,
                'clave' => $actualiza_clave,
                'idrol' => $actualiza_idrol,
                'email' => $actualiza_email,
                'telefono' => $actualiza_telefono,
                'documento' => $actualiza_documento,
                'foto' => $actualiza_foto,
                'id' => $editar_id
            ]);

            header("Location: administradorregistra.php?updated=true");
            exit();
        }

        // Eliminación de datos
        if (isset($_GET['borrar'])) {
            $borrar_id = $_GET['borrar'];
            $borrar = "DELETE FROM usuarios WHERE id = :id";
            $stmt = $pdo->prepare($borrar);
            $stmt->execute(['id' => $borrar_id]);

            header("Location: administradorregistra.php?updated=true");
            exit();
        }

        // Obtención de datos para la paginación
        $porPagina = 5;
        $pagina = isset($_GET['pagina']) ? $_GET['pagina'] : 1;
        $empieza = ($pagina - 1) * $porPagina;
        
        $totalRegistrosQuery = "SELECT COUNT(id) AS total FROM usuarios";
        $totalRegistrosStmt = $pdo->query($totalRegistrosQuery);
        $totalRegistros = $totalRegistrosStmt->fetch(PDO::FETCH_ASSOC)['total'];
        $totalPaginas = ceil($totalRegistros / $porPagina);
        
        $consulta = "SELECT * FROM usuarios LIMIT :empieza, :porPagina";
        $stmt = $pdo->prepare($consulta);
        $stmt->bindParam(':empieza', $empieza, PDO::PARAM_INT);
        $stmt->bindParam(':porPagina', $porPagina, PDO::PARAM_INT);
        $stmt->execute();
        ?>

        <div class="header-content container">
            <div class="header-img">
                <h1>bienvenid@ administrador@</h1>
                <img src="images/file.png" class="no-animate">
            </div>
            <div class="header-tt">
                <form action="" method="POST" enctype="multipart/form-data">
                    <h2>administrar registros</h2>
                    <p>administrador desde aqui puedes registra un nuevo usuario.</p>
                    <div class="f1">
                        <label for="nomusuario">nombre</label>
                        <input type="text" id="nomusuario" name="nomusuario" required placeholder="pepito perez">
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <label for="correo">correo</label>
                            <input type="email" id="email" name="email" required placeholder="es@htmail.com">
                        </div>
                        <div class="in2">
                            <label for="telefono">telefono</label>
                            <input type="number" id="telefono" name="telefono" required placeholder="3555555551">
                        </div>
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <div class="input-box">
                                <label>clave</label>
                                <span class="icon">
                                    <ion-icon name="lock-closed"></ion-icon>
                                </span>
                                <input type="password" required name="clave" id="clave" placeholder="********">
                            </div>
                        </div>
                        <div class="in2">
                            <label for="documento">numero de documento</label>
                            <input type="number" id="documento" name="documento" required placeholder="311544515051">
                        </div>
                    </div>
                    <div class="f2">
                        <label for="foto">Foto</label>
                        <input type="file" id="foto" name="foto" accept="image/*">
                    </div>
                    <input type="submit" name="insertar" value="registrar" class="btn-1">
                </form>
            </div>
        </div>

        <section class="bonus8">
            <div class="bonus-info1">
                <table border="3" align="center">
                    <center>
                        <tr style="background-color: red">
                            <th>ID</th>
                            <th>NOMBRE</th>
                            <th>IDROL</th>
                            <th>EMAIL</th>
                            <th>TELEFONO</th>
                            <th>DOCUMENTO</th>
                            <th>FOTO</th>
                            <th>EDITAR</th>
                            <th>BORRAR</th>
                        </tr>
                        <?php
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $id = $row['id'];
                            $nomusuario = $row['nomusuario'];
                            $clave = $row['clave'];
                            $idrol = $row['idrol'];
                            $email = $row['email'];
                            $telefono = $row['telefono'];
                            $documento = $row['documento'];
                            $foto = $row['foto'];
                        ?>
                        <tr>
                            <td><?php echo $id; ?></td>
                            <td><?php echo $nomusuario; ?></td>
                            <td>
                                <?php 
                                    if ($idrol == 1) {
                                        echo "Perfil de Administrador";
                                    } 
                                    else if ($idrol == 2) {
                                        echo "Perfil de Usuario";
                                    } 
                                ?>
                            </td>
                            <td><?php echo $email; ?></td>
                            <td><?php echo $telefono; ?></td>
                            <td><?php echo $documento; ?></td>
                            <td>
                                <?php if ($foto && file_exists("images/$foto")): ?>
                                    <img src="images/<?php echo $foto; ?>" alt="Foto de usuario" style="width: 100px; height: auto;">
                                <?php else: ?>
                                    <img src="images/default-profile.jpg" alt="Foto de usuario por defecto" style="width: 100px; height: auto;">
                                <?php endif; ?>
                            </td>
                            <td><a href="administradorregistra.php?editar=<?php echo $id; ?>">Editar</a></td>
                            <td><button style="background-color: orange"><a href="administradorregistra.php?borrar=<?php echo $id; ?>">Borrar</a></button></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </center>
                </table>

                <div style="text-align:center;">
                    <!-- Paginación -->
                    <?php 
                    $numLinks = 5;
                    $inicio = max(1, $pagina - floor($numLinks / 2));
                    $fin = min($inicio + $numLinks - 1, $totalPaginas);
                    $inicio = max(1, $fin - $numLinks + 1);

                    echo "<a href='administradorregistra.php?pagina=1'>Primera</a> ";
                    if ($pagina > 1) {
                        echo "<a href='administradorregistra.php?pagina=".($pagina - 1)."'>Anterior</a> ";
                    }
                    for ($i = $inicio; $i <= $fin; $i++) {
                        if ($i == $pagina) {
                            echo "<strong>".$i."</strong> ";
                        } else {
                            echo "<a href='administradorregistra.php?pagina=".$i."'>".$i."</a> ";
                        }
                    }
                    if ($pagina < $totalPaginas) {
                        echo "<a href='administradorregistra.php?pagina=".($pagina + 1)."'>Siguiente</a> ";
                    }
                    echo "<a href='administradorregistra.php?pagina=".$totalPaginas."'>Última</a>";
                    ?>
                </div>
            </div>
            
        </section>
        <div class="header-te">
            <?php
            if(isset($_GET['editar'])) {
                $editar_id = $_GET['editar'];
                $consulta = "SELECT * FROM usuarios WHERE id=:id";
                $stmt = $pdo->prepare($consulta);
                $stmt->execute(['id' => $editar_id]);
                $fila = $stmt->fetch(PDO::FETCH_ASSOC);
                $id = $fila['id'];
                $nomusuario = $fila['nomusuario'];
                $clave = $fila['clave'];
                $idrol = $fila['idrol'];
                $email = $fila['email'];
                $telefono = $fila['telefono'];
                $documento = $fila['documento'];
                $foto = $fila['foto'];
            ?>  
            <form method="POST" action="" enctype="multipart/form-data" style="color:white;" align="center">
                <h3>
                    NOMBRE   <input type="text" name="nomusuario" value="<?php echo $nomusuario; ?>"><br>
                    PASSWORD <input type="password" name="clave" value="<?php echo $clave; ?>"><br>
                    ROL      <input type="number" name="idrol" value="<?php echo $idrol; ?>"><br>
                    EMAIL    <input type="text" name="email" value="<?php echo $email; ?>"><br>
                    TELEFONO <input type="number" name="telefono" value="<?php echo $telefono; ?>"><br>
                    DOCUMENTO <input type="number" name="documento" value="<?php echo $documento; ?>"><br>
                    FOTO    <input type="file" name="foto" accept="image/*"><br>
                    <input type="hidden" name="foto_actual" value="<?php echo $foto; ?>">
                    <input type="submit" name="actualizar" value="Actualizar Datos"><br>
                </h3>    
            </form>  
            <?php
            }
            ?>
        </div>
    </body>
</html>
