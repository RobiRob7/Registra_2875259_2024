<?php
// Iniciar la sesión de forma segura
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Conectar a la base de datos usando MySQLi
$conexion = mysqli_connect("localhost", "root", "", "registra");
if (!$conexion) {
    die("Problema en la conexión: " . mysqli_connect_error());
}
// Verificar si el usuario ha iniciado sesión
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email']; // Obtener el email del usuario desde la sesión
    // Preparar y ejecutar la consulta para obtener datos del usuario
    $consulta = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = mysqli_prepare($conexion, $consulta);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    if ($fila = mysqli_fetch_assoc($resultado)) {
        // Asignar valores desde la base de datos
        $id = $fila['id'];
        $nomusuario = $fila['nomusuario'];
        $clave = $fila['clave']; // La clave se almacenó hasheada
        $idrol = $fila['idrol'];
        $email = $fila['email'];
        $telefono = $fila['telefono'];
        $documento = $fila['documento'];
        $foto = $fila['foto'];
        // Actualizar las variables de sesión
        $_SESSION['clave'] = $clave;
        $_SESSION['email'] = $email;
    } else {
        echo "No hay información del usuario disponible.";
        exit();
    }
    mysqli_stmt_close($stmt); // Cerrar el statement
} else {
    echo "No hay información del usuario disponible.";
    exit();
}
// Procesar la actualización de la información del usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Sanitizar entradas del formulario
    $nuevo_nomusuario = htmlspecialchars(trim($_POST['nomusuario']));
    $nuevo_telefono = htmlspecialchars(trim($_POST['telefono']));
    $nuevo_documento = htmlspecialchars(trim($_POST['documento']));
    $nueva_clave = htmlspecialchars(trim($_POST['clave']));
    // Verificar si la contraseña ha cambiado y hashearla si es necesario
    if (!password_verify($nueva_clave, $clave)) {
        $nueva_clave_hashed = password_hash($nueva_clave, PASSWORD_DEFAULT); // Hashear la nueva clave
    } else {
        $nueva_clave_hashed = $clave; // Mantener la clave actual si no ha cambiado
    }
    // Actualizar la información del usuario
    $consulta = "UPDATE usuarios SET nomusuario = ?, telefono = ?, documento = ?, clave = ? WHERE id = ?";
    $stmt = mysqli_prepare($conexion, $consulta);
    mysqli_stmt_bind_param($stmt, "ssssi", $nuevo_nomusuario, $nuevo_telefono, $nuevo_documento, $nueva_clave_hashed, $id);
    if (mysqli_stmt_execute($stmt)) {
        // Verificar si se ha subido una nueva imagen
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $foto_name = basename($_FILES['foto']['name']);
            $foto_tmp_name = $_FILES['foto']['tmp_name'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            // Validar tipo de archivo
            if (in_array($_FILES['foto']['type'], $allowed_types)) {
                $foto_path = __DIR__ . '/images/' . $foto_name;
                // Mover el archivo subido
                if (move_uploaded_file($foto_tmp_name, $foto_path)) {
                    // Actualizar la ruta de la foto en la base de datos
                    $consulta_update_foto = "UPDATE usuarios SET foto = ? WHERE id = ?";
                    $stmt_update_foto = mysqli_prepare($conexion, $consulta_update_foto);
                    mysqli_stmt_bind_param($stmt_update_foto, "si", $foto_name, $id);
                    mysqli_stmt_execute($stmt_update_foto);
                    mysqli_stmt_close($stmt_update_foto);

                    echo "Imagen subida y actualizada correctamente.";
                } else {
                    echo "Error al subir la imagen.";
                }
            } else {
                echo "Tipo de archivo no permitido. Solo se aceptan JPEG, PNG, o GIF.";
            }
        }
        echo "Información actualizada correctamente.";
        // Actualizar las variables de sesión
        $_SESSION['clave'] = $nueva_clave_hashed;
        // Redirigir al perfil
        header("Location: perfil.php");
        exit();
    } else {
        echo "Error al actualizar la información.";
    }
    mysqli_stmt_close($stmt); // Cerrar el statement
}
// Cerrar la conexión
mysqli_close($conexion);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRA</title>
    <link rel="icon" href="registra.ico">
    <link rel="stylesheet" href="stylee.css">
    <link rel="stylesheet" href="fontawesome/css/all.css">
</head>
<body>
<section class="bonus">
    <?php
    // Mostrar menú según el rol del usuario
    function mostrarMenu($idrol) {
        ?>
        <div class="menu containert">
            <a href="#" class="logo">Registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">Mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <?php if ($idrol == 1) { ?>
                            <li><a href="admineventos.php">Registro de Eventos</a></li>
                            <li><a href="administradorregistra.php">Registros</a></li>
                        <?php } ?>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </nav>
        </div>
        <?php
    }
    // Mostrar el menú basado en el rol
    mostrarMenu($idrol);
    ?>
    <section class="bonus">
        <div class="container">
            <div class="shape">
                <div class="image">
                    <!-- Mostrar la imagen de perfil si existe -->
                    <?php if ($foto && file_exists("images/$foto")): ?>
                        <img src="images/<?php echo $foto; ?>" alt="Foto de usuario" style="width: 100px; height: 100px; border-radius: 50%;">
                    <?php else: ?>
                        <img src="images/default-profile.jpg" alt="Foto de usuario por defecto" style="width: 100px; height: 100px; border-radius: 50%;">
                    <?php endif; ?>
                </div>
            </div>
            <h3>
                <?php
                    if ($idrol == 1) {
                        echo "Perfil de Administrador";
                    } else if ($idrol == 2) {
                        echo "Perfil de Usuario";
                    }
                ?>
            </h3>
            <h4 class="title">
                <?php echo htmlspecialchars($nomusuario); ?><br>
            </h4>
            <p>
                <form id="updateForm" action="" method="POST" enctype="multipart/form-data">
                    <label for="nomusuario">Nombre de Usuario:</label>
                    <input type="text" name="nomusuario" value="<?php echo htmlspecialchars($nomusuario); ?>" required><br>
                    
                    <label for="telefono">Número de Teléfono:</label>
                    <input type="text" name="telefono" value="<?php echo htmlspecialchars($telefono); ?>" required><br>
                    
                    <label for="documento">Documento:</label>
                    <input type="text" name="documento" value="<?php echo htmlspecialchars($documento); ?>" required><br>
                    
                    <label for="foto">Foto de Perfil:</label>
                    <input type="file" name="foto"><br>
                    
                    <input type="submit" name="update" value="Actualizar Información">
                </form>
            </p>
            <div class="icons">
                <i class="fa-brands fa-youtube"></i>
                <i class="fa-brands fa-instagram"></i>
                <i class="fa-brands fa-tiktok"></i>
                <i class="fa-brands fa-github"></i>
            </div>
        </div>
    </section>
</section>
</body>
</html>
