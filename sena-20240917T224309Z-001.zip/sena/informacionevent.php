<?php
session_start();
include_once 'conexionpdoregistra.php';

// Verificar si la sesión está iniciada
if (!isset($_SESSION['rol'])) {
    // Redirigir a la página de inicio de sesión si la sesión no está iniciada
    header("Location: inicioses.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if ($id === false) {
        echo "ID de evento no válido.";
        exit();
    }

    try {
        $db = new Database();
        $conexion = $db->conectar();
        
        // Obtener detalles del evento
        $consulta = "SELECT * FROM eventos WHERE id = :id";
        $stmt = $conexion->prepare($consulta);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $evento = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($evento) {
            $_SESSION['evento'] = $evento;
            
            // Verificar el rol del usuario y redirigir en consecuencia
            $idrol = $_SESSION['rol'];
            switch ($idrol) {
                case 1:
                    header("Location: procesar_registro_evento.php");
                    break;
                case 2:
                    header("Location: procesar_registro_evento.php");
                    break;
                default:
                    header("Location: inicioses.php");
                    break;
            }
            exit();
        } else {
            echo "Evento no encontrado.";
        }
    } catch (PDOException $e) {
        echo "Error en la conexión a la base de datos: " . $e->getMessage();
    }
} else {
    echo "ID de evento no proporcionado.";
}
?>
