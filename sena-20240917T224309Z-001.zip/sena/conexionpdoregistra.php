<?php
class Database
{
    private $servidorlocal = 'localhost';
    private $basededatos = 'registra';
    private $usuario = 'root';
    private $password = '';
    private $caracteres = 'utf8';

    public function conectar()
    {
        try {
            $conexion = "mysql:host=" . $this->servidorlocal . ";dbname=" . $this->basededatos . ";charset=" . $this->caracteres;
            $opciones = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false
            ];
            $pdo = new PDO($conexion, $this->usuario, $this->password, $opciones);
            return $pdo;
        } catch (PDOException $error) {
            // Cambia esta línea para mostrar el mensaje de error
            echo 'Error en la conexión: ' . $error->getMessage();
        }
    }
}
?>
