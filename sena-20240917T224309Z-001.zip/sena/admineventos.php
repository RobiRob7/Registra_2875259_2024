<?php
session_start();
if (!isset($_SESSION['rol'])) {
    header('location: inicioses.php');
    exit();
} else {
    if ($_SESSION['rol'] != 1) {
        header('Location: inicioses.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/file.ico">
</head>
<body background="images/sesion.jpg">
        <div class="menu container">
            <a href="#" class="logo">Registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="Menú">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <li><a href="admineventos.php">Registro de Eventos</a></li>
                        <li><a href="administradorregistra.php">Registros</a></li>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    <section class="bonus">
        <div class="header-content container">
            <div class="header-img">
                <h1>Bienvenid@ Administrador@</h1>
                <img src="images/file.png" class="no-animate" alt="Imagen de bienvenida">
            </div>
            <div class="header-tt">
                <form action="" method="POST" enctype="multipart/form-data">
                    <h2>Administrar Eventos</h2>
                    <p>Desde aquí puedes registrar un nuevo evento.</p>
                    <div class="f1">
                        <label for="nombre_eventos">Nombre del Evento</label>
                        <input type="text" id="nombre_eventos" name="nombre_eventos" required placeholder="Ingresa nombre de evento">
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <label for="artista">Artista</label>
                            <input type="text" id="artista" name="artista" required placeholder="Ingresa nombre artista">
                        </div>
                        <div class="in2">
                            <label for="fecha">Fecha</label>
                            <input type="date" id="fecha" name="fecha" required placeholder="Ingresa fecha">
                        </div>
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <label for="lugar">Ubicación</label>
                            <input type="text" id="lugar" name="lugar" required placeholder="Ubicación del evento">
                        </div>
                        <div class="in2">
                            <label for="valor">Valor</label>
                            <input type="number" id="valor" name="valor" required placeholder="Ingresa valor">
                        </div>
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <label for="foto_evento">Foto del Evento</label>
                            <input type="file" id="foto_evento" name="foto_evento" accept="image/*" required>
                        </div>
                        <div class="in2">
                            <label for="descripcion">Descripción</label>
                            <textarea id="descripcion" name="descripcion" required placeholder="Descripción del evento"></textarea>
                        </div>
                    </div>
                    <input type="submit" name="insertar" value="Registrar Evento" class="btn-1">
                </form>
            </div>
        </div>
    </section>
    
    <?php
    include_once 'conexionpdoregistra.php'; 
    $db = new Database();
    $conexion = $db->conectar();

    if (isset($_POST['insertar'])) {
        $nombre_eventos = $_POST['nombre_eventos'];
        $artista = $_POST['artista'];
        $fecha = $_POST['fecha'];
        $lugar = $_POST['lugar'];
        $valor = $_POST['valor'];
        $descripcion = $_POST['descripcion'];

        // Manejo de la foto del evento
        $foto_evento = $_FILES['foto_evento']['name'];
        $foto_evento_tmp = $_FILES['foto_evento']['tmp_name'];
        $foto_evento_path = 'images/' . $foto_evento;

        // Mover la foto del evento al directorio de imágenes
        move_uploaded_file($foto_evento_tmp, $foto_evento_path);

        $insertar = "INSERT INTO eventos (nombre_eventos, artista, fecha, lugar, valor, descripcion, foto_evento) 
                     VALUES (:nombre_eventos, :artista, :fecha, :lugar, :valor, :descripcion, :foto_evento)";

        $stmt = $conexion->prepare($insertar);
        $stmt->bindParam(':nombre_eventos', $nombre_eventos);
        $stmt->bindParam(':artista', $artista);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':lugar', $lugar);
        $stmt->bindParam(':valor', $valor);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':foto_evento', $foto_evento);

        if ($stmt->execute()) {
            header('Location: admineventos.php?updated=true');
            exit();
        } else {
            echo "Error al insertar datos.";
        }
    }

    if (isset($_POST['actualizar'])) {
        $id = $_POST['id'];
        $nombre_eventos = $_POST['nombre_eventos'];
        $artista = $_POST['artista'];
        $fecha = $_POST['fecha'];
        $lugar = $_POST['lugar'];
        $valor = $_POST['valor'];
        $descripcion = $_POST['descripcion'];

        // Manejo de la foto del evento
        $foto_evento = $_FILES['foto_evento']['name'];
        if ($foto_evento) {
            $foto_evento_tmp = $_FILES['foto_evento']['tmp_name'];
            $foto_evento_path = 'images/' . $foto_evento;
            move_uploaded_file($foto_evento_tmp, $foto_evento_path);
        } else {
            // Mantener la foto actual si no se ha subido una nueva
            $foto_evento = $_POST['foto_evento_actual'];
        }

        $actualizar = "UPDATE eventos SET nombre_eventos = :nombre_eventos, artista = :artista, fecha = :fecha, lugar = :lugar, 
                       valor = :valor, descripcion = :descripcion, foto_evento = :foto_evento WHERE id = :id";

        $stmt = $conexion->prepare($actualizar);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nombre_eventos', $nombre_eventos);
        $stmt->bindParam(':artista', $artista);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':lugar', $lugar);
        $stmt->bindParam(':valor', $valor);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':foto_evento', $foto_evento);

        if ($stmt->execute()) {
            header('Location: admineventos.php?updated=true');
            exit();
        } else {
            echo "Error al actualizar datos.";
        }
    }
    if (isset($_GET['borrar'])) {
        $id = $_GET['borrar'];
    
        // Primero, elimina las entradas relacionadas en la tabla registro_eventos
        $borrarRelacionados = "DELETE FROM registro_eventos WHERE id_evento = :id_evento";
        $stmtRelacionados = $conexion->prepare($borrarRelacionados);
        $stmtRelacionados->bindParam(':id_evento', $id);
        $stmtRelacionados->execute();
    
        // Luego, elimina la foto del evento del servidor
        $consultaFoto = "SELECT foto_evento FROM eventos WHERE id = :id";
        $stmtFoto = $conexion->prepare($consultaFoto);
        $stmtFoto->bindParam(':id', $id);
        $stmtFoto->execute();
        $filaFoto = $stmtFoto->fetch(PDO::FETCH_ASSOC);
        
        if ($filaFoto && !empty($filaFoto['foto_evento'])) {
            $fotoRuta = 'images/' . $filaFoto['foto_evento'];
            if (file_exists($fotoRuta)) {
                unlink($fotoRuta); // Elimina el archivo de la carpeta de imágenes
            }
        }
    
        // Finalmente, elimina el evento de la base de datos
        $borrar = "DELETE FROM eventos WHERE id = :id";
        $stmt = $conexion->prepare($borrar);
        $stmt->bindParam(':id', $id);
    
        if ($stmt->execute()) {
            header('Location: admineventos.php?deleted=true');
            exit();
        } else {
            echo "<p>Error al eliminar el evento.</p>";
        }
    }
    
    ?>

    <section class="bonus">
        <div class="bonus-info1">
            <?php
            $porPagina = 5;
            $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
            $empieza = ($pagina - 1) * $porPagina;
        
            $query = "SELECT * FROM eventos LIMIT :empieza, :porPagina";
            $stmt = $conexion->prepare($query);
            $stmt->bindValue(':empieza', $empieza, PDO::PARAM_INT);
            $stmt->bindValue(':porPagina', $porPagina, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>
            <table border="1" align="center">
                <tr style="background-color: red">
                    <th>Nombre del Evento</th>
                    <th>ID</th>
                    <th>Artista</th>
                    <th>Fecha</th>
                    <th>Lugar</th>
                    <th>Valor</th>
                    <th>Descripción</th>
                    <th>Foto del Evento</th>
                    <th>Editar</th>
                    <th>Borrar</th>
                </tr>
                <?php 
                foreach ($resultado as $fila) {
                ?>
                    <tr>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['nombre_eventos']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['id']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['artista']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['fecha']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['lugar']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><?php echo htmlspecialchars($fila['valor']); ?></td>
                        <td style="font-size: 10px; text-align: center;"><?php echo htmlspecialchars($fila['descripcion']); ?></td>
                        <td style="font-size: 15px; text-align: center;"><img src="images/<?php echo htmlspecialchars($fila['foto_evento']); ?>" alt="Foto del Evento" width="100"></td>
                        <td><a href="admineventos.php?editar=<?php echo $fila['id']; ?>">Editar</a></td>
                        <td><button style="background-color: orange"><a href="admineventos.php?borrar=<?php echo $fila['id']; ?>">Borrar</a></button></td>
                    </tr>
                <?php 
                } 
                ?>
            </table>

            <div>
                <center>
                <?php
                $consultaTotal = "SELECT COUNT(id) AS total FROM eventos";
                $stmtTotal = $conexion->prepare($consultaTotal);
                $stmtTotal->execute();
                $totalRegistros = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];
                $totalPaginas = ceil($totalRegistros / $porPagina);

                $numLinks = 5;
                $inicio = max(1, $pagina - floor($numLinks / 2));
                $fin = min($inicio + $numLinks - 1, $totalPaginas);
                $inicio = max(1, $fin - $numLinks + 1);

                echo "<a href='admineventos.php?pagina=1'>Primera</a> ";
                if ($pagina > 1) {
                    echo "<a href='admineventos.php?pagina=" . ($pagina - 1) . "'>Anterior</a> ";
                }
                for ($i = $inicio; $i <= $fin; $i++) {
                    if ($i == $pagina) {
                        echo "<strong>" . $i . "</strong> ";
                    } else {
                        echo "<a href='admineventos.php?pagina=" . $i . "'>" . $i . "</a> ";
                    }
                }

                if ($pagina < $totalPaginas) {
                    echo "<a href='admineventos.php?pagina=" . ($pagina + 1) . "'>Siguiente</a> ";
                }
                echo "<a href='admineventos.php?pagina=" . $totalPaginas . "'>Última</a>";
                ?>
                </center>
            </div>
        </div>

        <?php
        if (isset($_GET['editar'])) {
            $editar_id = $_GET['editar'];
            $consulta = "SELECT * FROM eventos WHERE id = :editar_id";
            $stmt = $conexion->prepare($consulta);
            $stmt->bindParam(':editar_id', $editar_id, PDO::PARAM_INT);
            $stmt->execute();
            $fila = $stmt->fetch(PDO::FETCH_ASSOC);
        
            // Obtén los valores de la fila
            $nombre_eventos = $fila['nombre_eventos'];
            $id = $fila['id'];
            $artista = $fila['artista'];
            $fecha = $fila['fecha'];
            $lugar = $fila['lugar'];
            $valor = $fila['valor'];
            $descripcion = $fila['descripcion'];
            $foto_evento = $fila['foto_evento'];
        ?>
        <div class="header-content">
            <div class="header-img">
                <img src="images/file.png" class="no-animate" alt="Imagen de edición">
            </div>
            <div class="header-tt">
                <form method="POST" action="" enctype="multipart/form-data" style="color: white;">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <label for="nombre_eventos">Nombre del Evento:</label>
                    <input type="text" id="nombre_eventos" name="nombre_eventos" value="<?php echo htmlspecialchars($nombre_eventos); ?>" required><br>

                    <label for="artista">Artista:</label>
                    <input type="text" id="artista" name="artista" value="<?php echo htmlspecialchars($artista); ?>" required><br>

                    <label for="fecha">Fecha:</label>
                    <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fecha); ?>" required><br>

                    <label for="lugar">Lugar:</label>
                    <input type="text" id="lugar" name="lugar" value="<?php echo htmlspecialchars($lugar); ?>" required><br>

                    <label for="valor">Valor:</label>
                    <input type="number" id="valor" name="valor" value="<?php echo htmlspecialchars($valor); ?>" required><br>

                    <label for="descripcion">Descripción:</label>
                    <textarea id="descripcion" name="descripcion" required><?php echo htmlspecialchars($descripcion); ?></textarea><br>

                    <label for="foto_evento">Foto del Evento:</label>
                    <input type="file" id="foto_evento" name="foto_evento" accept="image/*"><br>
                    <input type="hidden" name="foto_evento_actual" value="<?php echo htmlspecialchars($foto_evento); ?>"><br>

                    <input type="submit" name="actualizar" value="Actualizar">
                </form>
            </div>
        </div>
        <?php
        }
        ?>
    </section>
</body>
</html>
