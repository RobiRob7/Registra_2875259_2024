<?php
session_start(); // Asegúrate de iniciar la sesión al principio del archivo
include_once 'conexionpdoregistra.php';

// Verifica si el usuario ha enviado el formulario de inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['clave'])) {
    $email = $_POST['email'];
    $clave = $_POST['clave'];
    $db = new Database();

    // Prepara y ejecuta la consulta
    $query = $db->conectar()->prepare('SELECT * FROM usuarios WHERE email = :email AND clave = :clave');
    $query->execute(['email' => $email, 'clave' => $clave]);
    $arreglofila = $query->fetch(PDO::FETCH_NUM);

    if ($arreglofila) {
        $id = $arreglofila[0]; 
        $idrol = $arreglofila[3]; 
        $_SESSION['id'] = $id;
        $_SESSION['rol'] = $idrol;
        $_SESSION['email'] = $arreglofila[4]; 

        switch ($idrol) {
            case 1:
                header('Location: perfil.php');
                exit;
            case 2:
                header('Location: perfil.php');
                exit;
            default:
                echo "Este rol no existe dentro de las opciones";
                exit;
        }
    } else {
        $_SESSION['error'] = 'Tu email o clave son incorrectas. Intenta nuevamente.';
        header('Location: inicioses.php');
        exit;
    }
}

// Verifica si ya hay una sesión iniciada y redirige según el rol
if (isset($_SESSION['rol'])) {
    switch ($_SESSION['rol']) {
        case 1:
            header('Location: perfil.php');
            exit;
        case 2:
            header('Location: perfil.php');
            exit;
        default:
            echo 'Rol desconocido';
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="styleses.css">
    <link rel="icon" href="images/file.ico">
</head>

<body>
    <div class="menu container">
        <a href="#" class="logo">registra</a>
        <input type="checkbox" id="menu" />
        <label for="menu">
            <img src="images/menu.png" class="menu-icono" alt="">
        </label>
        <nav class="navbar">
            <div class="menu-1">
                <ul>
                    <li><a href="index1.php">inicio</a></li>
                    <li><a href="eventos.php">eventos</a></li>
                    <li><a href="inicioses.php">iniciar sesión</a></li>
                </ul>
            </div>
        </nav>
    </div>

    <section>
        <div class="login-box">
            <form action="" method="POST">
                <h2>Iniciar Sesión</h2>
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="mail"></ion-icon>
                    </span>
                    <input type="email" name="email" required>
                    <label>Correo</label>
                </div>
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="lock-closed"></ion-icon>
                    </span>
                    <input type="password" name="clave" required>
                    <label>Clave</label>
                </div>
                <input type="submit" value="Iniciar Sesión" class="styled-button">
                <div class="register-link">
                    <p>Aún no tiene una Cuenta?<a href="registro.php"> Regístrese</a></p>
                </div>
            </form>

            <style>
                .styled-button {
                    border-radius: 10px;
                    display: inline-block;
                    padding: 12px 35px;
                    font-size: 15px;
                    text-transform: uppercase;
                    background: transparent;
                    color: #00949E;
                    border: 3px solid #00949E;
                    margin-left: 60px;
                    box-shadow: 0 0 10px 5px rgba(1, 255, 242, 0.6);
                }

                .styled-button:hover {
                    background-color: #00949E;
                    color: #ffffff;
                    border: 3px solid #ffffff;
                }
            </style>

            <!-- Modal -->
            <div id="myModal" class="modal">
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <p id="modal-message"></p>
                </div>
            </div>

            <script>
                // Obtener el modal
                var modal = document.getElementById("myModal");

                // Obtener el botón que cierra el modal
                var span = document.getElementsByClassName("close")[0];

                // Cuando el usuario hace clic en <span> (x), cerrar el modal
                span.onclick = function() {
                    modal.style.display = "none";
                }

                // Cuando el usuario hace clic fuera del modal, cerrarlo
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
            </script>

            <?php
            // Mostrar mensaje de error si existe
            if (isset($_SESSION['error'])) {
                echo "<script>
                        document.getElementById('modal-message').innerText = '" . $_SESSION['error'] . "';
                        document.getElementById('myModal').style.display = 'block';
                      </script>";
                unset($_SESSION['error']); // Eliminar el mensaje de error después de mostrarlo
            }
            ?>
        </div>
    </section>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>
