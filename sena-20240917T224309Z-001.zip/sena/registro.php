<?php
include_once 'conexionpdoregistra.php';

if (isset($_POST['registrar'])) {
    $nomusuario = $_POST['nomusuario'];
    $clave = $_POST['clave'];
    $idrol = 2; // ID del rol de usuario
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $documento = $_POST['documento'];

    // Nombre de la imagen por defecto
    $foto = 'default-profile.jpg';

    try {
        $db = new Database();
        $pdo = $db->conectar();

        // Sentencia preparada para evitar inyección SQL
        $sql = "INSERT INTO usuarios (nomusuario, email, clave, telefono, documento, idrol, foto) VALUES (:nomusuario, :email, :clave, :telefono, :documento, :idrol, :foto)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'nomusuario' => $nomusuario,
            'email' => $email,
            'telefono' => $telefono,
            'documento' => $documento,
            'clave' => $clave,
            'idrol' => $idrol,
            'foto' => $foto // Se asigna la imagen por defecto
        ]);
    } catch (PDOException $e) {
        // Manejo de errores 
        echo "Error al registrar el usuario: " . $e->getMessage();
    }
}
?>

<?php
session_start();
if(isset($_SESSION['rol'])) {
    switch ($_SESSION['rol']) {
        case 1:
        case 2:
            header('Location: perfil.php');
            break;
        default:
            echo 'No está entrando';
            break;
    }
}

if (isset($_POST['email']) && isset($_POST['clave'])) {
    $email = $_POST['email'];
    $clave = $_POST['clave'];
    $db = new Database();
    $query = $db->conectar()->prepare('SELECT * FROM usuarios WHERE email=:email AND clave=:clave');
    $query->execute(['email' => $email, 'clave' => $clave]);
    $arreglofila = $query->fetch(PDO::FETCH_NUM);

    if ($arreglofila) {
        $idrol = $arreglofila[3]; // Asegúrate de que esta es la posición correcta para idrol
        $_SESSION['rol'] = $idrol;
        switch ($idrol) {
            case 1:
            case 2:
                header('Location: perfil.php');
                break;
            default:
                echo "Este rol no existe dentro de las opciones";
                break;
        }
        $email = $arreglofila[4];
        $_SESSION['email'] = $email;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/file.ico">
</head>
<body>
    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                        <li><a href="index1.php">inicio</a></li>
                        <li><a href="eventos.php">eventos</a></li>
                        <li><a href="inicioses.php">iniciar sesion</a></li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="header-content container">
            <div class="header-img">
                <img src="images/file.png" class="no-animate">
            </div>
            <div class="header-tt">
                <h1>registrate</h1>
                <p>
                    registrate y reserva los mejores eventos a tu disposición, crea recuerdos y vive el momento.
                </p>
                <form action="registro.php" method="POST">
                    <div class="f1">
                        <label for="nomusuario">nombre</label>
                        <input type="text" id="nomusuario" name="nomusuario" required placeholder="pepito perez">
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <label for="email">correo</label>
                            <input type="email" id="email" name="email" required placeholder="es@htmail.com">
                        </div>
                        <div class="in2">
                            <label for="telefono">telefono</label>
                            <input type="number" id="telefono" name="telefono" required placeholder="3555555551">
                        </div>
                    </div>
                    <div class="f2">
                        <div class="in1">
                            <div class="input-box">
                                <label>clave</label>
                                <span class="icon">
                                    <ion-icon name="lock-closed"></ion-icon>
                                </span>
                                <input type="password" required name="clave" id="clave" placeholder="*******">
                            </div>
                        </div>
                        <div class="in2">
                            <label for="documento">numero de documento</label>
                            <input type="number" id="documento" name="documento" required placeholder="311544515051">
                        </div>
                    </div>
                    <input type="submit" name="registrar" value="registrar" class="btn-1">
                </form>
            </div>
        </div>
    </header>
</body>
</html>
