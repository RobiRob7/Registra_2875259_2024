<?php
include_once 'conexionpdoregistra.php';

if (isset($_POST['insertar'])) 
{
    $nomusuario = $_POST['nomusuario'];
    $clave = $_POST['clave'];
    $idrol = 2; // ID del rol de usuario;
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $documento = $_POST['documento']; 
    $db = new Database();
    $pdo = $db->conectar();
    $sql = "INSERT INTO usuarios (nomusuario, email, clave, telefono, documento, idrol) VALUES (:nomusuario, :email, :clave, :telefono, :documento, :idrol)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'nomusuario' => $nomusuario,
        'email' => $email,
        'telefono' => $telefono,
        'documento' => $documento,
        'clave' => $clave,
        'idrol' => $idrol // Quita el punto y coma (;) al final de esta línea
    ]);
    // Redirigir a inicioses.php después del registro exitoso
    header("Location: inicioses.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/file.ico">
</head>
<body>
    <section class="bonus">
            <div class="menu container">
                <a href="#" class="logo">registra</a>
                <input type="checkbox" id="menu" />
                <label for="menu">
                    <img src="images/menu.png" class="menu-icono" alt="">
                </label>
                <nav class="navbar">
                    <div class="menu-1">
                        <ul>
                            <li><a href="index1.php">inicio</a></li>
                            <li><a href="eventos.php">eventos</a></li>
                            <li><a href="inicioses.php">iniciar sesion</a></li>
                        </ul>
                    </div>
                </nav>        
            </div>
        <div class="bonus-content container">
            <h2>¿QUIENES SOMOS? 
            ¿QUE HACEMOS?</h2>
            <div class="bonus-info">
                <div class="bonus-1">
                    <h1> SOMOS REGISTRA UNA PAGINA COMPROMETIDA CON EL CLIENTE</h1>
                    <p>
                    "NOS PREOCUPAMOS POR LA SEGURIDAD DEL CLIENTE, Y NOS DEDICAMOS A HACER UN REGISTRO DE PERSONAS QUE ASISTEN A LOS EVENTOS!<BR>
                            PARA TENER UN CONTROL SOBRE CUANTO ESPECTADOR ASISTIO!
                            TAMBIEN SE GENERA UN REGISTRO DE EVENTOS LOS CUALES SE OFRECEN A TRAVES DE LA PAGINA!
                            SE OFRECEN EVENTOS DE LA MEJOR CALIDAD PARA USTEDES, MANEJANDO LA CALIDAD,SEGURIDAD Y EL ENTRETENIMIENTO Y UN MEJOR PRECIO PARA MAYOR COMODIDAD AL BOLSILLO"<BR>
                            CADA DIA VAMOS MEJORANDO PARA QUE USTED COMO CLIENTE SE SIENTA MAS CONTENTO DE ESTAR DE NOSOTROS,
                            <BR>PARA USTEDES Y POR USTEDES.
                    </p>
                </div>
                <div class="bonus-3">
                    <img src="images/file.png" >
                </div>
            </div>
        </div>
    </section>
    <section class="break">
        <div class="containert">
            <div class="breakfast-2">
                <h3>tenemos los mejores eventos de la ciudad de bogota</h3>
                <p>
                    "¡Reserva tus boletos ahora y no te pierdas ningún evento! ¡Las mejores experiencias
                    a solo un clic!"
                </p>
            </div>
            <div class="item-containert">
                <div class="img-containert">
                    <img src="images/fut.jpg" alt="Event image">
                </div>

                <div class="body-containert">
                    <div class="overlay"></div>

                    <div class="eventt-info">
                        <center>
                            <p class="title"> Alianza.p vs Juventinos</p>
                            <div class="separator"></div>
                            <p class="infot">Estadio techo, BOGOTA</p>
                            <p class="price">$$$</p>
                        </center>

                        <div class="additionalt-info">
                            <p class="infott">
                                <i class="fas fa-map-marker-alt"></i>
                                estadio de Techo
                            </p>
                            <p class="infott">
                                <i class="far fa-calendar-alt"></i>
                                Dom, Sep 19, 10:00 AM
                            </p>

                            <p class="infotdescription">
                                promete ser una experiencia llena de emoción y buen fútbol, donde ambos equipos
                                competirán por el orgullo y el honor de llevarse la victoria en este clásico encuentro.
                                ENTRADAS: $$$ Occidental,$$$ Oriental,$$$ Sur,$$$ Norte
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item-containert">
                <div class="img-containert">
                    <img src="images/cris.jpeg.jpg" alt="Event image">
                </div>

                <div class="body-containert">
                    <div class="overlay"></div>

                    <div class="eventt-info">
                        <center>
                            <p class="title">Cris Velencia <BR>El primer exito</p>
                            <div class="separator"></div>
                            <p class="infott">Bogota, Movistar arena</p>
                            <p class="price">777-111</p>
                        </center>

                        <div class="additionalt-info">
                            <p class="infott">
                                <i class="fas fa-map-marker-alt"></i>
                                Movistar arena, Bogota.
                            </p>
                            <p class="infott">
                                <i class="far fa-calendar-alt"></i>
                                Viernes, Ago 09, 12:00 PM
                            </p>

                            <p class="infodescription">
                                Cris velencia, artista revelación está rompiendo todos los récords. Con unas nuevas
                                canciones, este espectáculo promete ser una experiencia inolvidable para todos los
                                asistentes ENTRADAS: $$$50.000 General $$$ 100.000 VIP.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bonus">
        <div class="bonus-content container">
            <h2>visita nuestras nuevas ofertas</h2>
            <div class="bonus-info">
                <div class="bonus-1">
                    <h3>ofertas unicas</h3>
                    <p>
                        "Descubre nuestras ofertas únicas diseñadas especialmente para ti. Descuentos exclusivos en tus
                        eventos favoritos, disponibles por tiempo limitado. ¡No dejes pasar esta oportunidad de vivir
                        experiencias inolvidables a precios increíbles! Reserva ahora y asegura tus boletos antes de que
                        se agoten. ¡Actúa rápido y disfruta de momentos únicos!"
                    </p>
                </div>
                <div class="bonus-2">
                    <img src="images/map.png" alt="Map image">
                </div>
            </div>
        </div>
    </section>
    <section class="ubication">
        <div class="container">
            <h2>nuestros eventos</h2>
            <div class="ubication-1">
                <div class="info">
                    <h3>conciertos en</h3>
                    <p>
                        campin 
                    </p>
                    <p>
                        movistar arena 
                    </p>
                    <p>
                        simon bolivar  
                    </p>
                </div>
                <div class="info">
                    <h3>obras de teatro</h3>
                    <p>
                        terror
                    </p>
                    <p>
                        historia
                    </p>
                    <p>
                        romance
                    </p>
                </div>
                <div class="info">
                    <h3>partidos de futbol</h3>
                    <p>
                        en los estadios de :
                    </p>
                    <p>
                        techo
                    </p>
                    <p>
                        el campin

                    </p>
                    <p>
                        en las categorias :
                    </p>
                    <p>
                        sub 15, amateur y profesional
                    </p>
                </div>
                <div class="info">
                    <h3>festivales</h3>
                    <p>
                         de verano 
                    </p>
                    <p>
                        musica 
                    </p>
                    <p>
                        cultura 
                    </p>
                    <p>
                        de terror 
                    </p>
                </div>
            </div>
            <div class="ubication-2">
                <div class="info-1">
                    <p>
                        "Descubre nuestras ofertas únicas para una amplia gama de eventos: conciertos, obras de teatro,
                        partidos de fútbol, festivales de
                        música, espectáculos de comedia, exposiciones de arte y más.
                    </p>
                </div>
                <div class="info-2">
                    <img src="images/phone.png" alt="Phone image">
                </div>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Inicio
                </h3>
                <ul>
                    <li><a href="#">Conciertos</a> </li>
                    <li><a href="#">Espectáculos de comedia</a></li>
                    <li><a href="#">Obras de teatro</a> </li>
                    <li><a href="#">Partidos de fútbol</a> </li>
                    <li><a href="#">Festivales de música</a> </li>
                </ul>
            </div>
            <div class="link">
                <h3>Punto de venta
                </h3>
                <ul>
                    <li><a href="#">Promociones</a> </li>
                    <li><a href="#">Politicas de privacidad</a> </li>
                    <li><a href="#">Terminos y condiciones</a> </li>
                </ul>
            </div>
            <div class="link">
                <h3>comunicate con nosotros</h3>
                <ul>
                    <li><a href="#">gerencia</a> </li>
                    <li><a href="#">nuestros nueros de contacto</a> </li>
                    <li><a href="#">puntos de queja</a> </li>
                    <li><a href="#">dirigentes</a> </li>
                </ul>
            </div>
        </div>
    </footer>
</body>

</html>
