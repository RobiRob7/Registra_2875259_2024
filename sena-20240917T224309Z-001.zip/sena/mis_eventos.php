<?php
session_start();
include 'conexionpdoregistra.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['id'])) {
    header("Location: inicioses.php"); // Redirige al usuario a la página de inicio de sesión
    exit;
}

$id_asistente = $_SESSION['id'];
$mensaje = '';
$mensaje_clase = '';
$idrol = isset($_SESSION['rol']) ? $_SESSION['rol'] : null; // Asegúrate de definir el rol del usuario

try {
    $db = new Database();
    $conexion = $db->conectar();

    // Obtener los eventos a los que el usuario está registrado
    $sql_eventos = "SELECT e.* 
                    FROM eventos e
                    INNER JOIN registro_eventos r ON e.id = r.id_evento
                    WHERE r.id_asistente = :id_asistente";
    $query = $conexion->prepare($sql_eventos);
    $query->bindParam(':id_asistente', $id_asistente, PDO::PARAM_INT);
    $query->execute();
    $eventos = $query->fetchAll(PDO::FETCH_ASSOC);

    if (empty($eventos)) {
        $mensaje = "No estás registrado en ningún evento.";
        $mensaje_clase = "info";
    }
} catch (PDOException $e) {
    $mensaje = "Error en la conexión a la base de datos: " . $e->getMessage();
    $mensaje_clase = "error";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="registra.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <title>REGISTRA</title>
    <style>
        .alert {
            padding: 10px;
            margin-top: 10px;
            color: white;
            border-radius: 5px;
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 80%;
            max-width: 600px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .alert.info {
            background-color: blue;
        }
        .alert.error {
            background-color: red;
        }
        .alert .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }
        .event-container {
            padding: 20px;
            color: white; /* Cambia el color del texto a blanco */
            border-radius: 5px;
            margin: 60px auto;
            max-width: 800px;
            background: transparent;
            border: 2px solid rgb(0, 195, 255);
            backdrop-filter: blur(15px);
            box-shadow: 0 0 10px 5px rgba(1, 255, 242, 0.6);
        }
        .event-container img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
    </style>
</head>
<body background="images/sesion.jpg">

    <div class="menu containert">
        <a href="#" class="logo">Registra</a>
        <input type="checkbox" id="menu" />
        <label for="menu">
            <img src="images/menu.png" class="menu-icono" alt="Menu">
        </label>
        <nav class="navbar">
            <div class="menu-1">
                <ul>
                    <?php if ($idrol == 2): ?>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">Mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    <?php elseif ($idrol == 1): ?>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">Mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <li><a href="admineventos.php">Registro de Eventos</a></li>
                        <li><a href="administradorregistra.php">Registros</a></li>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    <?php else: ?>
                        <?php header("Location: inicioses.php"); exit(); ?><?php endif; ?>
                </ul>
            </div>
        </nav>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert <?php echo htmlspecialchars($mensaje_clase); ?>" id="alertMessage">
            <?php echo htmlspecialchars($mensaje); ?>
            <button class="close-btn" onclick="closeAlert()">×</button>
        </div>
    <?php endif; ?>

    <?php if (!empty($eventos)): ?>
        <?php foreach ($eventos as $evento): ?>
            <div class="event-container">
                <center>
                    <?php if (!empty($evento['foto_evento'])): ?>
                        <img src="images/<?php echo htmlspecialchars($evento['foto_evento']); ?>" alt="Foto del Evento" style="width: 150px; height: 100px; border-radius: 10%;">
                    <?php else: ?>
                        <img src="images/placeholder.png" alt="Imagen no disponible">
                    <?php endif; ?>
                    <h3><?php echo htmlspecialchars($evento['nombre_eventos']); ?></h3>
                </center>
                <p><strong>Artista:</strong> <?php echo htmlspecialchars($evento['artista']); ?></p>
                <p><strong>Fecha:</strong> <?php echo htmlspecialchars($evento['fecha']); ?></p>
                <p><strong>Lugar:</strong> <?php echo htmlspecialchars($evento['lugar']); ?></p>
                <p><strong>Valor:</strong> <?php echo htmlspecialchars($evento['valor']); ?></p>
                <p><strong>Descripción:</strong> <?php echo htmlspecialchars($evento['descripcion']); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <script>
        function closeAlert() {
            var alert = document.getElementById('alertMessage');
            alert.style.display = 'none';
        }
    </script>
</body>
</html>
