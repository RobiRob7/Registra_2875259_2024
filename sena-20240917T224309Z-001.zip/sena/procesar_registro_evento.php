<?php
session_start();
include 'conexionpdoregistra.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['rol'])) {
    header("Location: inicioses.php"); // Redirige al usuario a la página de inicio de sesión
    exit;
}

// Verificar si $_SESSION['id'] está definido
if (!isset($_SESSION['id'])) {
    header("Location: inicioses.php"); // Redirige al usuario a la página de inicio de sesión
    exit;
}

// Variables para almacenar mensajes
$mensaje = '';
$mensaje_clase = '';

if (isset($_POST['evento_id'])) {
    $id_evento = filter_input(INPUT_POST, 'evento_id', FILTER_VALIDATE_INT);
    if ($id_evento === false) {
        $mensaje = "ID de evento no válido.";
        $mensaje_clase = "error";
    } else {
        $id_asistente = $_SESSION['id'];

        try {
            $db = new Database();
            $conexion = $db->conectar();
            
            // Registrar en el evento
            $sql_registro = "INSERT INTO registro_eventos (id_asistente, id_evento) VALUES (:id_asistente, :id_evento)";
            $query = $conexion->prepare($sql_registro);
            $query->bindParam(':id_asistente', $id_asistente, PDO::PARAM_INT);
            $query->bindParam(':id_evento', $id_evento, PDO::PARAM_INT);

            if ($query->execute()) {
                $mensaje = "Registro exitoso.";
                $mensaje_clase = "success";
            } else {
                $mensaje = "Error en la ejecución de la consulta: " . $query->errorInfo()[2];
                $mensaje_clase = "error";
            }
        } catch (PDOException $e) {
            $mensaje = "Error en la conexión a la base de datos: " . $e->getMessage();
            $mensaje_clase = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="registra.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .alert {
            padding: 10px;
            margin-top: 10px;
            color: white;
            border-radius: 5px;
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 80%;
            max-width: 600px;
            text-align: center;
        }
        .alert.info {
            background-color: blue;
        }
        .alert.error {
            background-color: red;
        }
        .event-container {
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            margin: 20px auto;
            max-width: 800px;
            background: transparent;
        border: 2px solid rgb(0, 195, 255);
        backdrop-filter: blur(15px);
        box-shadow: 0 0 10px 5px rgba(1, 255, 242, 0.6);
        color: #f9f9f9;
        }
        .event-container img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .event-container h2 {
            font-size: 25px;
        }
    </style>
</head>
<body>
    <div class="menu-container">
        <div class="menu container">
            <a href="#" class="logo">Registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                        <li><a href="perfil.php">Perfil</a></li>
                        <li><a href="mis_eventos.php">Mis Eventos</a></li>
                        <li><a href="eventos1.php">Eventos</a></li>
                        <?php if ($_SESSION['rol'] == 1): ?>
                            <li><a href="admineventos.php">Registro de Eventos</a></li>
                            <li><a href="administradorregistra.php">Registros</a></li>
                        <?php endif; ?>
                        <li><a href="cerrarses.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <section class="break">
        <h5 style="font-size: 25px; color:#f9f9f9">Registro al Evento</h2>
        <?php if ($mensaje): ?>
            <div class="alert <?php echo htmlspecialchars($mensaje_clase); ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>
        <div class="event-container">
        <?php if (isset($_SESSION['evento'])): ?>
            <?php
            $evento = $_SESSION['evento'];
            $foto_evento = htmlspecialchars($evento['foto_evento']);
            $nombre_eventos = htmlspecialchars($evento['nombre_eventos']);
            $artista = htmlspecialchars($evento['artista']);
            $fecha = htmlspecialchars($evento['fecha']);
            $lugar = htmlspecialchars($evento['lugar']);
            $valor = htmlspecialchars($evento['valor']);
            $descripcion = htmlspecialchars($evento['descripcion']);
            ?>
            <div>
                <center>
                        <?php if (!empty($evento['foto_evento'])): ?>
                            <img src="images/<?php echo htmlspecialchars($evento['foto_evento']); ?>" alt="Foto del Evento" style="width: 150px; height: 100px; border-radius: 10%;">
                        <?php else: ?>
                            <img src="images/placeholder.png" alt="Imagen no disponible">
                        <?php endif; ?>
                </center>
                <h2><?php echo $nombre_eventos; ?></h2>
                <p><strong>Artista:</strong> <?php echo $artista; ?></p>
                <p><strong>Fecha:</strong> <?php echo $fecha; ?></p>
                <p><strong>Lugar:</strong> <?php echo $lugar; ?></p>
                <p><strong>Valor:</strong> <?php echo $valor; ?></p>
                <p><strong>Descripción:</strong> <?php echo $descripcion; ?></p>
            </div>
            <form id="registroForm" action="" method="post">
                <input type="hidden" name="evento_id" value="<?php echo htmlspecialchars($evento['id']); ?>">
                <input type="submit" value="Registrar">
            </form>
        <?php else: ?>
            <p>No hay información del evento disponible.</p>
        <?php endif; ?>
    </div>
    </section>
    <script>
        document.getElementById('registroForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevenir el envío del formulario
            
            const formData = new FormData(this);
            
            fetch('procesar_registro_evento.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                const alertBox = document.createElement('div');
                alertBox.classList.add('alert');
                
                if (data.includes("Registro exitoso")) {
                    alertBox.classList.add('success');
                    alertBox.innerText = 'Registro exitoso.';
                    setTimeout(() => window.location.reload(), 2000); // Recargar la página después de 2 segundos
                } else {
                    alertBox.classList.add('error');
                    alertBox.innerText = data;
                }
                
                document.body.appendChild(alertBox);
            })
            .catch(error => {
                console.error('Error:', error);
                const alertBox = document.createElement('div');
                alertBox.classList.add('alert', 'error');
                alertBox.innerText = 'Hubo un problema con el registro.';
                document.body.appendChild(alertBox);
            });
        });
    </script>
</body>
</html>
