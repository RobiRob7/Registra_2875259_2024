<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="registra.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <title>REGISTRA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/file.ico">
</head>
<body>
        <div class="menu container">
            <a href="#" class="logo">registra</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="">
            </label>
            <nav class="navbar">
                <div class="menu-1">
                    <ul>
                    <li><a href="index1.php">inicio</a></li>
                    <li><a href="eventos.php">eventos</a></li>
                    <li><a href="inicioses.php">iniciar sesion</a></li>
                </ul>
            </div>
        </nav>
    </div>
    <section class="break">
        <div class="containert">
        <?php
        include_once 'conexionpdoregistra.php';
        $db = new Database();
        $conexion = $db->conectar();
        $consulta = "SELECT * FROM eventos";
        $ejecutar = $conexion->query($consulta);
        $eventos_ids=[];
        $i = 0;
        while ($fila = $ejecutar->fetch(PDO::FETCH_ASSOC)) {
            $nombre_eventos = $fila['nombre_eventos'];
            $id = $fila['id'];
            $artista = $fila['artista'];
            $fecha = $fila['fecha'];
            $lugar = $fila['lugar'];
            $valor = $fila['valor'];
            $descripcion = $fila['descripcion'];
            $foto_evento = $fila['foto_evento'];
            $eventos_ids[] = $id;
            $i++;    
        ?>
            <div class="item-containert">
                <div class="img-containert">
                <td style="font-size: 15px; text-align: center;"><img src="images/<?php echo htmlspecialchars($fila['foto_evento']); ?>" alt="Foto del Evento" width="100"></td>
                </div>
                <div class="body-containert">
                    <div class="overlay"></div>
                    <div class="eventt-info">
                        <center>
                            <p class="title"><?php echo $nombre_eventos ?></p>
                            <div class="separator"></div>
                            <p class="infot"><?php echo $artista ?> </p>
                            <p class="price"><?php echo $valor ?></p>
                        </center>
                        <div class="additionalt-info">
                            <p class="infott">
                                <i class="fas fa-map-marker-alt"></i>
                                <?php echo $lugar ?>
                            </p>
                            <p class="infott">
                                <i class="far fa-calendar-alt"></i>
                                <?php echo $fecha ?>
                            </p>

                            <p class="infotdescription">
                            <?php echo $descripcion ?>
                            </p>
                        </div>
                    </div>
                    <button class="actiont" onclick="window.location.href='informacionevent.php?id=<?php echo $id; ?>'">INFORMACION</button>
                    </div>
            </div>
        <?php
        }
        ?>
    </section>
</body>
</html>